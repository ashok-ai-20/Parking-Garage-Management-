package model;

public class Car extends Vehicle {
    public Car(String number, String owner) { super(number, owner); }
    @Override public String getVehicleType() { return "CAR"; }
}
