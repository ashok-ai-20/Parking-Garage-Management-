package util;

import java.util.Scanner;
import exception.InvalidInputException;

public class InputHelper {
    private final Scanner scanner;
    public InputHelper(Scanner scanner) { this.scanner = scanner; }

    public String readText(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) throw new InvalidInputException("Input cannot be empty.");
        return value;
    }
    public int readInt(String prompt, int min, int max) throws InvalidInputException {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        try {
            int number = Integer.parseInt(value);
            if (number < min || number > max)
                throw new InvalidInputException("Enter a number between " + min + " and " + max + ".");
            return number;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid whole number.");
        }
    }
}
