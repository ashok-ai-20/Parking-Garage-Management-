package exception;

public class SpotUnavailableException extends ParkingException {
    private static final long serialVersionUID = 1L;
    public SpotUnavailableException(String message) { super(message); }
}
