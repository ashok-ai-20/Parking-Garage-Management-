# Parking Garage Management

**Student:** ASHOK NATARAJAN R  
**Register Number:** 717825I304  
**Course:** 23CSR306 – Java Programming  
**Specification:** 14 – Parking Garage Management

## Problem statement
Develop a menu-driven Java console application to manage parking lots, spots, vehicles, tickets, tariffs, payments and exits.

## Features
- Configure car, bike and truck parking spots.
- Allocate only a suitable available spot to each entering vehicle.
- Generate a ticket with vehicle, spot and entry time.
- Calculate parking fee using vehicle type and billable duration.
- Require payment before exit and release the spot after successful payment.
- Display current occupancy and available spaces.
- Validate menu and text input and handle application errors without crashing.

## OOP concepts
- **Encapsulation:** private data members and public methods.
- **Inheritance:** `Car`, `Bike`, and `Truck` extend abstract `Vehicle`.
- **Aggregation:** `ParkingLot` contains a list of `ParkingSpot` objects.
- **Polymorphism:** `Vehicle` references can refer to different vehicle subclasses.

## Packages
`model`, `service`, `util`, `exception`, `main`

## Requirements
Java 11 or later.

## Compile and run
From the project directory:

```bash
mkdir -p out
javac -d out src/model/*.java src/service/*.java src/util/*.java src/exception/*.java src/main/*.java
java -cp out main.Main
```

In Eclipse, create a Java project, copy the `src` package structure into the project's `src` folder, then run `main.Main`.

## Tariff used
- Car: Rs. 30 per billable hour
- Bike: Rs. 15 per billable hour
- Truck: Rs. 60 per billable hour

A minimum of one billable hour is charged; partial hours are rounded up.

## Student details
ASHOK NATARAJAN R — 717825I304
