package model;

import java.util.ArrayList;
import java.util.List;

public class ParkingLot {
    private String lotName;
    private final List<ParkingSpot> spots = new ArrayList<>();

    public ParkingLot(String lotName) { this.lotName = lotName; }
    public String getLotName() { return lotName; }
    public void setLotName(String lotName) { this.lotName = lotName; }
    public List<ParkingSpot> getSpots() { return spots; }
    public void addSpot(ParkingSpot spot) { spots.add(spot); }
}
