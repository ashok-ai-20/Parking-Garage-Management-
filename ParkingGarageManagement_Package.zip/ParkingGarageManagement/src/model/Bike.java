package model;

public class Bike extends Vehicle {
    public Bike(String number, String owner) { super(number, owner); }
    @Override public String getVehicleType() { return "BIKE"; }
}
