package model;

import java.time.LocalDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class Ticket {
    private String ticketId;
    private Vehicle vehicle;
    private ParkingSpot spot;
    private LocalDateTime entryTime;
    private boolean paid;

    public Ticket(String ticketId, Vehicle vehicle, ParkingSpot spot) {
        this.ticketId = ticketId; this.vehicle = vehicle; this.spot = spot;
        this.entryTime = LocalDateTime.now(); this.paid = false;
    }
    public String getTicketId() { return ticketId; }
    public Vehicle getVehicle() { return vehicle; }
    public ParkingSpot getSpot() { return spot; }
    public LocalDateTime getEntryTime() { return entryTime; }
    public boolean isPaid() { return paid; }
    public void markPaid() { paid = true; }
    public long getBillableHours() {
        long minutes = Math.max(1, Duration.between(entryTime, LocalDateTime.now()).toMinutes());
        return Math.max(1, (minutes + 59) / 60);
    }
    public String getFormattedEntryTime() {
        return entryTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
    }
}
