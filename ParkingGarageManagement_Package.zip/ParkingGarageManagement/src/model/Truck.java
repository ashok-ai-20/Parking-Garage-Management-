package model;

public class Truck extends Vehicle {
    public Truck(String number, String owner) { super(number, owner); }
    @Override public String getVehicleType() { return "TRUCK"; }
}
