package model;

public class ParkingSpot {
    private final String spotId;
    private final String supportedType;
    private Vehicle vehicle;

    public ParkingSpot(String spotId, String supportedType) {
        this.spotId = spotId;
        this.supportedType = supportedType;
    }
    public String getSpotId() { return spotId; }
    public String getSupportedType() { return supportedType; }
    public Vehicle getVehicle() { return vehicle; }
    public boolean isAvailable() { return vehicle == null; }
    public boolean supports(Vehicle v) {
        return supportedType.equals("ANY") || supportedType.equals(v.getVehicleType());
    }
    public void park(Vehicle v) { vehicle = v; }
    public void release() { vehicle = null; }
}
