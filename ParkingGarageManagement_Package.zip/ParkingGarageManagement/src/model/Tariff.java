package model;

public class Tariff {
    private double carRate;
    private double bikeRate;
    private double truckRate;

    public Tariff(double carRate, double bikeRate, double truckRate) {
        this.carRate = carRate; this.bikeRate = bikeRate; this.truckRate = truckRate;
    }
    public double rateFor(String type) {
        switch (type) {
            case "CAR": return carRate;
            case "BIKE": return bikeRate;
            case "TRUCK": return truckRate;
            default: return carRate;
        }
    }
}
