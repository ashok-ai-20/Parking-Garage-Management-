package main;

import java.util.Scanner;
import model.Ticket;
import model.Payment;
import service.ParkingService;
import util.InputHelper;
import exception.ParkingException;

public class Main {
    private static void printMenu() {
        System.out.println("\n========== PARKING GARAGE MANAGEMENT ==========");
        System.out.println("1. Configure Lot & Spots");
        System.out.println("2. Vehicle Entry (Issue Ticket)");
        System.out.println("3. Vehicle Exit (Calculate Fee & Pay)");
        System.out.println("4. Display Occupancy");
        System.out.println("5. Exit");
        System.out.println("================================================");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InputHelper input = new InputHelper(scanner);
        ParkingService service = new ParkingService();
        boolean running = true;
        System.out.println("Welcome to Parking Garage Management System");
        while (running) {
            printMenu();
            try {
                int choice = input.readInt("Enter choice (1-5): ", 1, 5);
                switch (choice) {
                    case 1:
                        int cars = input.readInt("Number of car spots (0-100): ", 0, 100);
                        int bikes = input.readInt("Number of bike spots (0-100): ", 0, 100);
                        int trucks = input.readInt("Number of truck spots (0-100): ", 0, 100);
                        service.configureSpots(cars, bikes, trucks);
                        break;
                    case 2:
                        String type = input.readText("Vehicle type (CAR/BIKE/TRUCK): ");
                        String number = input.readText("Vehicle number: ");
                        String owner = input.readText("Owner name: ");
                        Ticket ticket = service.vehicleEntry(type, number, owner);
                        System.out.println("\n========== TICKET ISSUED ==========");
                        System.out.println("Ticket ID : " + ticket.getTicketId());
                        System.out.println("Vehicle   : " + ticket.getVehicle().getVehicleNumber());
                        System.out.println("Type      : " + ticket.getVehicle().getVehicleType());
                        System.out.println("Spot      : " + ticket.getSpot().getSpotId());
                        System.out.println("Entry time: " + ticket.getFormattedEntryTime());
                        System.out.println("===================================");
                        break;
                    case 3:
                        String ticketId = input.readText("Enter ticket ID: ");
                        Ticket active = service.findTicket(ticketId);
                        System.out.print(service.calculateFee(active));
                        String confirm = input.readText("Confirm payment? (YES/NO): ");
                        if (confirm.equalsIgnoreCase("YES")) {
                            Payment payment = service.payAndExit(ticketId);
                            System.out.print(payment.receipt());
                            System.out.println("[OK] Exit permitted. Spot " + active.getSpot().getSpotId() + " is now available.");
                        } else {
                            System.out.println("Payment cancelled. Vehicle remains parked.");
                        }
                        break;
                    case 4:
                        service.displayOccupancy();
                        break;
                    case 5:
                        System.out.println("Thank you for using Parking Garage Management System.");
                        running = false;
                        break;
                    default:
                        break;
                }
            } catch (ParkingException e) {
                System.out.println("[ERROR] " + e.getMessage());
            } catch (RuntimeException e) {
                System.out.println("[ERROR] Invalid input. Please try again.");
            }
        }
        scanner.close();
    }
}
