package exception;

public class ItemNotFoundException extends ParkingException {
    private static final long serialVersionUID = 1L;
    public ItemNotFoundException(String message) { super(message); }
}
