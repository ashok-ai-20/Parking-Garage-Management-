package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Payment {
    private String paymentId;
    private String ticketId;
    private double amount;
    private LocalDateTime paymentTime;

    public Payment(String paymentId, String ticketId, double amount) {
        this.paymentId = paymentId; this.ticketId = ticketId;
        this.amount = amount; this.paymentTime = LocalDateTime.now();
    }
    public String getPaymentId() { return paymentId; }
    public String getTicketId() { return ticketId; }
    public double getAmount() { return amount; }
    public String receipt() {
        return "\n========== PAYMENT RECEIPT ==========\n" +
               "Payment ID : " + paymentId + "\nTicket ID  : " + ticketId +
               "\nAmount     : Rs. " + String.format("%.2f", amount) +
               "\nPaid At    : " + paymentTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")) +
               "\nStatus     : PAID\n=====================================\n";
    }
}
