package service;

import java.util.*;
import model.*;
import exception.*;

public class ParkingService {
    private final ParkingLot lot = new ParkingLot("KCE Parking Garage");
    private final Map<String, Ticket> activeTickets = new LinkedHashMap<>();
    private final Map<String, Payment> payments = new LinkedHashMap<>();
    private final Tariff tariff = new Tariff(30.0, 15.0, 60.0);
    private int ticketSequence = 1, paymentSequence = 1;

    public ParkingLot getLot() { return lot; }

    public void configureSpots(int cars, int bikes, int trucks) throws InvalidInputException {
        if (!lot.getSpots().isEmpty()) throw new InvalidInputException("Spots are already configured.");
        if (cars + bikes + trucks < 1) throw new InvalidInputException("Add at least one parking spot.");
        int id = 1;
        for (int i=0; i<cars; i++) lot.addSpot(new ParkingSpot("S" + id++, "CAR"));
        for (int i=0; i<bikes; i++) lot.addSpot(new ParkingSpot("S" + id++, "BIKE"));
        for (int i=0; i<trucks; i++) lot.addSpot(new ParkingSpot("S" + id++, "TRUCK"));
        System.out.println("[OK] Configured " + lot.getSpots().size() + " parking spots.");
    }

    public Ticket vehicleEntry(String type, String number, String owner) throws ParkingException {
        Vehicle vehicle;
        switch (type.toUpperCase()) {
            case "CAR": vehicle = new Car(number.toUpperCase(), owner); break;
            case "BIKE": vehicle = new Bike(number.toUpperCase(), owner); break;
            case "TRUCK": vehicle = new Truck(number.toUpperCase(), owner); break;
            default: throw new InvalidInputException("Vehicle type must be CAR, BIKE, or TRUCK.");
        }
        for (ParkingSpot spot : lot.getSpots()) {
            if (spot.isAvailable() && spot.supports(vehicle)) {
                spot.park(vehicle);
                String id = String.format("T%03d", ticketSequence++);
                Ticket ticket = new Ticket(id, vehicle, spot);
                activeTickets.put(id, ticket);
                return ticket;
            }
        }
        throw new SpotUnavailableException("No suitable parking spot is available for " + type + ".");
    }

    public String calculateFee(Ticket ticket) {
        long hours = ticket.getBillableHours();
        double rate = tariff.rateFor(ticket.getVehicle().getVehicleType());
        return "\n========== FEE BREAKDOWN ==========\nTicket ID : " + ticket.getTicketId() +
               "\nVehicle   : " + ticket.getVehicle().getVehicleNumber() +
               "\nDuration  : " + hours + " hour(s)" +
               "\nHourly rate: Rs. " + String.format("%.2f", rate) +
               "\nTotal fee : Rs. " + String.format("%.2f", hours * rate) +
               "\n==================================\n";
    }

    public Payment payAndExit(String ticketId) throws ParkingException {
        Ticket ticket = activeTickets.get(ticketId);
        if (ticket == null) throw new ItemNotFoundException("Active ticket not found.");
        if (ticket.isPaid()) throw new InvalidInputException("This ticket is already paid.");
        long hours = ticket.getBillableHours();
        double amount = hours * tariff.rateFor(ticket.getVehicle().getVehicleType());
        ticket.markPaid();
        Payment payment = new Payment(String.format("P%03d", paymentSequence++), ticketId, amount);
        payments.put(ticketId, payment);
        ticket.getSpot().release();
        activeTickets.remove(ticketId);
        return payment;
    }

    public Ticket findTicket(String ticketId) throws ItemNotFoundException {
        Ticket ticket = activeTickets.get(ticketId);
        if (ticket == null) throw new ItemNotFoundException("Active ticket not found.");
        return ticket;
    }

    public void displayOccupancy() {
        System.out.println("\n========== PARKING OCCUPANCY ==========");
        if (lot.getSpots().isEmpty()) {
            System.out.println("No spots configured yet.");
        } else {
            for (ParkingSpot s : lot.getSpots()) {
                String status = s.isAvailable() ? "AVAILABLE" :
                    "OCCUPIED by " + s.getVehicle().getVehicleNumber();
                System.out.printf("%-5s | %-5s | %s%n", s.getSpotId(), s.getSupportedType(), status);
            }
            long occupied = lot.getSpots().stream().filter(s -> !s.isAvailable()).count();
            System.out.println("Total: " + lot.getSpots().size() + " | Occupied: " + occupied +
                               " | Available: " + (lot.getSpots().size() - occupied));
        }
        System.out.println("=======================================\n");
    }
}
